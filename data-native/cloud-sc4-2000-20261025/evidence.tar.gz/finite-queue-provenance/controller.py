#!/usr/bin/env python3
"""One finite two-case continuation: SC4, then conditional SC8.
Stage owners retain global dual locks; this queue holds its own duplicate lock.
No unlimited loop or service lifetime claim. Source freezes precede each solve.
"""
import sys,os,json,time,signal,subprocess,threading,hashlib,argparse,shutil,urllib.parse
from pathlib import Path
sys.dont_write_bytecode=True
ROOT=Path('/workspace/ngg-tis-task1');sys.path.insert(0,str(ROOT/'tools'))
import task1_bounded_continuation as b,task1_execution_policy as ep
PUBLISHER=Path('/dev/shm/task1-git-publication-20261025/source/git_publish_plan.py')
def req(ok,msg):
 if not ok:raise ValueError(msg)
def read(p):return json.loads(Path(p).read_text())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def new(p,o):
 with Path(p).open('x')as f:json.dump(o,f,ensure_ascii=False,allow_nan=False,indent=2)
def size(p):return p.stat().st_size if p.is_file()else sum(q.stat().st_size for q in p.rglob('*')if q.is_file())
args=argparse.ArgumentParser();args.add_argument('--output',required=True);args.add_argument('--owner',required=True);args.add_argument('--run',required=True);args.add_argument('--next-owner');args.add_argument('--next-run');cli=args.parse_args();OUT=Path(cli.output)
req(OUT.parent==ROOT/'runtime/finite-native-queue-20261025'and not OUT.exists(),'Unique preserved queue output');OUT.mkdir();(OUT/'logs').mkdir()
with b.dual_lock(ROOT/'.task1-queue-owner.lock'):
 start=time.monotonic();pid=os.getpid();ticks=b.ticks(pid);owned={pid:ticks};stop=threading.Event();limits=ep.resolve_limits();ep.configure_process(limits);state=dict(phase='starting',case=None,peak_RSS=0,peak_owned_tmpfs=0,peak_accounted=0);counter=0;child_wall=0.;active_child=None;queue_started_utc=b.now();own_comment_ids=set();receipt=dict(schema='task1-finite-two-case-queue-v1',status='failed_preserved',queue_pid=pid,queue_start_ticks=ticks,maximum_cases=2,outer_deadline_seconds=2400,cumulative_time_unlimited=True,resource_limits=limits,never_attempt_SC16=True)
 def checkpoint(phase,case=None,**extra):
  global counter
  counter+=1;data=dict(schema='task1-active-finite-queue-checkpoint-v1',updated_utc=b.now(),queue_pid=pid,queue_start_ticks=ticks,phase=phase,case=case,elapsed_seconds=time.monotonic()-start,**extra);new(OUT/('checkpoint-'+str(counter).zfill(4)+'.json'),data);tmp=OUT/('current-'+str(counter)+'.tmp');new(tmp,data);os.replace(tmp,OUT/'current.json');target=ROOT/'runtime/task1-live-native-controller.json';temp=target.with_name('task1-live-'+str(pid)+'-'+str(counter)+'.tmp');new(temp,data);os.replace(temp,target);state.update(phase=phase,case=case)
 def guard():
  known=b.owned_descendants(pid,ticks,dict(owned));owned.update(known);rss=sum(b.rss(v)for v,t in known.items()if b.live(v,t));tmp=sum(size(q)for q in Path('/dev/shm').glob('task1-*'));state.update(peak_RSS=max(state['peak_RSS'],rss),peak_owned_tmpfs=max(state['peak_owned_tmpfs'],tmp),peak_accounted=max(state['peak_accounted'],rss+tmp));req(rss+tmp<=limits['total_memory_bytes'],'Aggregate queue+childrenRSS+ALLtasktmpfs8GB');req(time.monotonic()-start<2400,'Finite two-case queue deadline')
 def interrupt(s,f):raise InterruptedError(state.get('error','External signal/environment stop or finite queue timeout'))
 def monitor():
  while not stop.wait(1):
   try:guard()
   except BaseException as e:state['error']=str(e);os.kill(pid,signal.SIGTERM);return
 handlers={s:signal.getsignal(s)for s in(signal.SIGALRM,signal.SIGINT,signal.SIGTERM)}
 for s in handlers:signal.signal(s,interrupt)
 signal.setitimer(signal.ITIMER_REAL,2400);thread=threading.Thread(target=monitor,daemon=True);thread.start()
 def command(argv,label,timeout,allow_transport=False,run=None):
  global active_child,child_wall
  guard();checkpoint(label,str(run)if run else None);log=OUT/'logs'/(str(counter)+'-'+label+'.log');before=time.monotonic()
  with log.open('xb')as stream:
   active_child=subprocess.Popen(argv,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True);owned[active_child.pid]=b.ticks(active_child.pid);checkpoint(label,str(run)if run else None,child_pid=active_child.pid,child_start_ticks=owned[active_child.pid],log=str(log))
   try:code=active_child.wait(timeout=min(timeout,2400-(time.monotonic()-start)))
   finally:
    if active_child.poll()is None:active_child.terminate();active_child.wait(timeout=5)
    child_wall+=time.monotonic()-before;active_child=None
  if code and allow_transport and run is not None and(run/'publish-results-receipt.json').is_file():
   if read(run/'publish-results-receipt.json')['status']=='requires_supported_Git_transport':return
  req(code==0,'Finite child stage failed: '+label+'; log='+str(log))
 def completed(run,stage):
  file=run/(stage+'-receipt.json')
  if not file.is_file():return False
  r=read(file)
  if stage=='execute':return r.get('new_native_conditions_completed')==1 and(run/'native-sha256.json').is_file()
  if stage=='postprocess':return r.get('status','').startswith('new_native_postprocessed')and(run/'postprocess/artifact-sha256.json').is_file()
  if stage=='persist':return r.get('local_native_and_post_hashes_verified')is True or r.get('cloud_native_and_post_hashes_verified')is True
  return False
 def run_case(owner,run):
  provenance=run/'finite-queue-provenance'
  if not provenance.exists():
   provenance.mkdir();shutil.copyfile(__file__,provenance/'controller.py');shutil.copyfile(OUT/'registration.json',provenance/'registration.json')
  publication=read(run/'source-publication.json');req(publication['status']=='published_readback_verified','Source already fullypublished beforePDE');req(sha(PUBLISHER)==registration['publisher_SHA256'],'Frozen Git publisher changed')
  if not completed(run,'execute'):command([sys.executable,'-B',str(owner),'--execute','--output',str(run)],'execute',225,run=run)
  if not completed(run,'postprocess'):command([sys.executable,'-B',str(owner),'--postprocess','--output',str(run)],'postprocess',165,run=run)
  if not(run/'result-publication.json').is_file():
   if not(run/'external-git-publication-plan.json').is_file():command([sys.executable,'-B',str(owner),'--publish-results','--output',str(run)],'prepare-publication',270,True,run)
   transport=Path('/dev/shm')/('task1-git-queue-'+run.name+'-'+str(pid));command([sys.executable,'-B',str(PUBLISHER),'--run',str(run),'--output',str(transport)],'supported-Git-publication',300,run=run)
   publication_receipt=read(transport/'receipt.json');url=publication_receipt.get('comment_url','')
   if '#issuecomment-'in url:own_comment_ids.add(int(url.rsplit('-',1)[-1]))
  if not completed(run,'persist'):command([sys.executable,'-B',str(owner),'--persist','--output',str(run)],'verify-persistence',65,run=run)
  req(read(run/'result-publication.json')['status']=='published_readback_verified','Result fullreadbackrequired');summary=read(run/'postprocess/summary.json');adj=next(v for k,v in summary.items()if k.startswith('adjacent_')and isinstance(v,dict)and'all_passed'in v);comparison=summary['independent_same_physical_region_comparison'];comparison=comparison.get('fixed23_75mm',comparison);rows=comparison.get('rows',[]);unresolved=any(r['order']=='common_two_point'and r.get('interface_depth_mm',100)<1 and not r['fine_passed']for r in rows);checkpoint('case_complete',str(run),adjacent_all_passed=adj['all_passed'],independent_common_two_unresolved=unresolved,result_commit=read(run/'result-publication.json')['commit']);return adj['all_passed'],unresolved
 try:
  first_owner=Path(cli.owner);first_run=Path(cli.run);registration=dict(schema='task1-finite-adaptive-SC-queue-registration-v1',source_SHA256=sha(__file__),first_owner=str(first_owner),first_run=str(first_run),publisher_SHA256=sha(PUBLISHER),resource_policy_refs=ep.execution_policy_refs(),max_cases=2,rule='AfterSC4fullpublication: if13adjacencyallpassANDcommon2QAunresolved, admit source-frozenSC8; otherwise preserve scientific blocker and do not run',outer_finite_deadline_seconds=2400)
  if cli.next_owner:registration.update(next_owner=cli.next_owner,next_run=cli.next_run,next_source_sha256={str(q):sha(q)for q in Path(cli.next_owner).parent.iterdir()if q.is_file()and q.suffix in('.py','.java','.json','.md')})
  new(OUT/'registration.json',registration)
  if cli.next_owner:
   snap=OUT/'proposed-next-source';snap.mkdir()
   for source,h in registration['next_source_sha256'].items():shutil.copyfile(source,snap/Path(source).name)
  checkpoint('registered',str(first_run));adj,unresolved=run_case(first_owner,first_run);cases=1
  query=urllib.parse.urlencode({'since':queue_started_utc,'per_page':100});feedback_log=OUT/'recent-feedback.json';guard()
  feedback_child=subprocess.Popen(['gh','api','repos/yoodohyun-codex-cloud/ngg-tis-task1/issues/2/comments?'+query,'--jq','map({id,html_url,created_at,updated_at,author:.user.login})'],stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True);owned[feedback_child.pid]=b.ticks(feedback_child.pid)
  try:feedback_raw,feedback_error=feedback_child.communicate(timeout=30)
  finally:
   if feedback_child.poll()is None:feedback_child.kill();feedback_child.wait(timeout=2)
  req(feedback_child.returncode==0,'ActualGitHubfeedbackcheckfailed; no unreviewedconditionaladmission');feedback=json.loads(feedback_raw);new(feedback_log,dict(since_utc=queue_started_utc,public_comments=feedback,excluded_own_ids=sorted(own_comment_ids)));unreviewed=[v for v in feedback if v['id']not in own_comment_ids]
  if unreviewed:checkpoint('external_feedback_review_pending',state['case'],feedback_ids=[v['id']for v in unreviewed])
  if cli.next_owner and adj and unresolved and not unreviewed:
   owner=Path(cli.next_owner);run=Path(cli.next_run)
   for q,h in registration['next_source_sha256'].items():req(sha(q)==h,'Conditional next source changed before admission')
   parent=read(first_run/'result-publication.json')['commit'];text=owner.read_text();placeholder='REPLACE_AFTER_ACTUAL_SC4_POST_DECISION_AND_PUBLICATION';req(text.count(placeholder)==1,'Exactly one preregistered next-parent placeholder');new(OUT/'conditional-next-admission.json',dict(actual_prior_result_commit=parent,actual_prior_adjacent_all_passed=adj,actual_prior_common2_unresolved=unresolved,source_before_SHA256=sha(owner),change='Bind actual parent commit only before nextprepare; no physics/data/gates changed',next_run=str(run)));owner.write_text(text.replace(placeholder,parent));new(OUT/'conditional-parent-binding.json',dict(source_after_SHA256=sha(owner),actual_parent=parent,only_change='preregistered parent placeholder bound before preparation'));checkpoint('conditional_SC8_admitted',str(run),actual_parent=parent)
   command([sys.executable,'-B',str(owner),'--prepare','--output',str(run)],'conditional-prepare',65,run=run);command([sys.executable,'-B',str(owner),'--publish-source','--output',str(run)],'conditional-source-publication',95,run=run);run_case(owner,run);cases+=1
  receipt.update(status='finite_queue_completed_feedback_review_pending'if unreviewed else'finite_queue_completed',pending_feedback_ids=[v['id']for v in unreviewed],cases_completed=cases,next_condition='Review retained interfaceflags/fitbias and numericalROI before next scientificbatch; no automaticSC16 beyond800k',last_case=state['case']);checkpoint('feedback_review_pending'if unreviewed else'finite_queue_completed',state['case'],cases_completed=cases,pending_feedback_ids=[v['id']for v in unreviewed],stop_reason='new public feedback requires scientific review'if unreviewed else'predeclared finite two-case scope completed; not cumulative time budget',next_condition=receipt['next_condition'])
 except BaseException as e:receipt.update(error_type=type(e).__name__,error=str(e),failed_phase=state['phase'],case=state['case']);checkpoint('failed_preserved',state['case'],failed_phase=state['phase'],error=str(e),stop_reason='actual numerical/transport/resource/error or external environment signal; not cumulative time budget');raise
 finally:
  signal.setitimer(signal.ITIMER_REAL,0);stop.set();thread.join(timeout=2)
  for v,t in b.owned_descendants(pid,ticks,dict(owned)).items():
   if v!=pid and b.live(v,t):
    try:os.kill(v,signal.SIGTERM)
    except ProcessLookupError:pass
  receipt.update(finished_utc=b.now(),wall_seconds=time.monotonic()-start,child_wall_seconds=child_wall,ledger_accounting='Child finite owners debit actual stages; orchestration wall is not double charged',resource_measurements={k:v for k,v in state.items()if k.startswith('peak_')});new(OUT/'receipt.json',receipt)
  for s,h in handlers.items():signal.signal(s,h)
  print(json.dumps(receipt,ensure_ascii=False))
