#!/usr/bin/env python3
"""Complete the exact preregistered2074 direction metric from saved native E.
No PDE; preserve the original deadline-limited analysis and all failures.
Only memory chunk size changes, from256 to2048cells; directions/formula/units
and physical scenario are identical. Original ROI masks and reference cutoffs.
"""
import sys,os,json,time,hashlib,gzip,io,signal,threading,shutil
from pathlib import Path
sys.dont_write_bytecode=True
for key in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS'):os.environ[key]='1'
ROOT=Path('/workspace/ngg-tis-task1');RUN=Path('/workspace/task1-experiment-2000-2010-20261025-run');CASE='baseline-square15-human-sine2000-2010-xy80';OUT=RUN/'modulation-completion';LEDGER=ROOT/'runtime/task1-budget.json';SOURCE=Path('/dev/shm/task1-experiment-2000-2010-20261025/source');CAP=35
sys.path[:0]=[str(ROOT/'tools'),str(SOURCE)]
import task1_bounded_continuation as bounded,task1_resource_policy as policy

def require(ok,msg):
 if not ok:raise ValueError(msg)
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb')as f:
  for b in iter(lambda:f.read(1024**2),b''):h.update(b)
 return h.hexdigest()
def read(p):return json.loads(Path(p).read_text())
def new(p,obj):
 with Path(p).open('x')as f:json.dump(obj,f,ensure_ascii=False,allow_nan=False,indent=2)
def size(p):
 if p.is_file():return p.stat().st_size
 return sum(q.stat().st_size for q in p.rglob('*')if q.is_file())
def main():
 with bounded.dual_lock(ROOT/'.task1-loop.lock'),bounded.dual_lock(ROOT/'.task1-execution.lock'):
  ledger=policy.load_ledger(LEDGER);require(policy.remaining_seconds(ledger)>=CAP+85,'Existing budget reserves raw publication75+persistence10');require(not OUT.exists(),'Preserve every prior completion attempt');OUT.mkdir();(OUT/'source').mkdir();shutil.copyfile(__file__,OUT/'source/complete_modulation.py')
  start=time.monotonic();pid=os.getpid();ticks=bounded.ticks(pid);os.sched_setaffinity(0,{min(os.sched_getaffinity(0))});stop=threading.Event();state=dict(peak_RSS=0,peak_owned_tmpfs=0,peak_accounted=0)
  receipt=dict(schema='task1-cached-modulation-completion-v1',status='failed_preserved',run_id=RUN.name,case_id=CASE,pid=pid,proc_start_ticks=ticks,started_utc=bounded.now(),stage_cap_seconds=CAP,new_PDE=0,source_SHA256=sha(__file__),original_postprocess_preserved=True,chunk_cells=2048,directions=2074,storage_capacity_guards_enabled=False)
  pins=read(RUN/'native-sha256.json')['files'];pins.update({str(RUN/'postprocess'/n):sha(RUN/'postprocess'/n)for n in('summary.json','scalars.npz')});before=dict(pins)
  def guard():
   require(time.monotonic()-start<CAP,'Finite cached completion deadline');rss=bounded.rss(pid);tmp=sum(size(p)for p in Path('/dev/shm').glob('task1-*'));state.update(peak_RSS=max(state['peak_RSS'],rss),peak_owned_tmpfs=max(state['peak_owned_tmpfs'],tmp),peak_accounted=max(state['peak_accounted'],rss+tmp));require(rss+tmp<=3*1024**3,'Original aggregateRAM3GiB')
  def interrupt(sig,frame):raise TimeoutError('Finite cached completion interrupted')
  def monitor():
   while not stop.wait(1):
    try:guard()
    except BaseException:os.kill(pid,signal.SIGTERM);return
  previous={s:signal.getsignal(s)for s in(signal.SIGTERM,signal.SIGINT,signal.SIGALRM)}
  for s in previous:signal.signal(s,interrupt)
  signal.setitimer(signal.ITIMER_REAL,CAP);thread=threading.Thread(target=monitor,daemon=True);thread.start()
  try:
   new(OUT/'registration.json',dict(source_SHA256=receipt['source_SHA256'],inputs=pins,question='Finish exact same2074-sampled directional modulation with larger memory chunks; no changed acceptance criteria',chunk_cells=2048,new_PDE=0,remaining_before_seconds=policy.remaining_seconds(ledger),limits=dict(CPU=1,RAM_bytes=3*1024**3,time_seconds=CAP)))
   for p,h in pins.items():guard();require(sha(p)==h,'Pinned native/postprocess changed')
   import numpy as np
   from experiment_math import _directions,weighted_statistics
   summary=read(RUN/'postprocess/summary.json');scenario=summary['scenarios']['human_2000_2010_sine'];require(scenario['maximum_direction_search']['status']=='not_run_to_completion_budget','Only recover explicitly discarded partial result')
   dirs=_directions();n=351680;basis=RUN/'bases'/CASE
   def field(f,ch):
    p=basis/('field-'+str(f)+'.bin.gz');r=gzip.decompress(p.read_bytes());require(len(r)==2*n*3*16,'Savedcomplex128 ABI');return np.frombuffer(r,dtype='<c16').reshape(2,n,3)[ch]
   a=field(2000,0);b=field(2010,1);maximum=np.zeros(n);winner=np.zeros(n,np.int32)
   for lo in range(0,n,2048):
    guard();hi=min(n,lo+2048);pa=np.abs(a[lo:hi]@dirs.T);pb=np.abs(b[lo:hi]@dirs.T);np.minimum(pa,pb,out=pa);ids=np.argmax(pa,axis=1);maximum[lo:hi]=2*pa[np.arange(hi-lo),ids];winner[lo:hi]=ids
   require(np.isfinite(maximum).all()and np.all(maximum>=0)and np.all(maximum<=2*np.minimum(np.linalg.norm(a,axis=1),np.linalg.norm(b,axis=1))+1e-9),'Finite sampled modulation and analyticupperbound');del a,b,pa,pb
   grid=np.loadtxt(io.BytesIO(gzip.decompress((basis/'grid.csv.gz').read_bytes())),delimiter=',',skiprows=1);guard()
   with np.load(RUN/'postprocess/scalars.npz',allow_pickle=False)as archive:weights={key[:-len('_volume_weight_m3')]:np.array(archive[key],copy=True)for key in archive.files if key.endswith('_volume_weight_m3')}
   cutoffbase=summary['scenarios']['legacy_3000_3030_sine']['statistics']['target']['fundamental_maxTIS_2074_V_m']['mean'];cutoffs=[cutoffbase*f for f in (.5,1,2)]
   for region,weight in weights.items():
    guard();stats=weighted_statistics(maximum,weight,grid);stats['high_modulation_volume']=[dict(cutoff_V_m=c,volume_m3=float(weight[maximum>=c].sum()),reference='0.5/1/2times legacy3k sine targetmean; numerical reference, not activation threshold')for c in cutoffs];scenario['statistics'][region]['fundamental_maxTIS_2074_V_m']=stats
   scenario['maximum_direction_search']=dict(status='complete',directions=2074,fibonacci_count=2048,chunk_cells=2048,metric='max sampled real unit n of2min(abs(n dot E2000),abs(n dot E2010))',scope='Same preregistered2074 finite sampled lower bound; memory-chunk-only completion from preserved nativefields; no PDE',original_discarded_partial=read(RUN/'postprocess/summary.json')['scenarios']['human_2000_2010_sine']['maximum_direction_search'])
   target=scenario['statistics']['target']['fundamental_maxTIS_2074_V_m']
   for normal in summary['normalizations'].values():
    for row in normal['rows']:row['target_AM_mean_V_m']=target['mean']*row['amplitude_scale'];row['target_AM_P10_V_m']=target['p10']*row['amplitude_scale']
   summary['modulation_completion']=dict(new_PDE=0,source_SHA256=receipt['source_SHA256'],original_summary_SHA256=pins[str(RUN/'postprocess/summary.json')],original_summary_preserved=True,original_time_limit_not_relaxed=True,separate_finite_followup_seconds=CAP)
   new(OUT/'summary.json',summary)
   with(OUT/'scalars.npz').open('xb')as f:np.savez_compressed(f,fundamental_maxTIS_2074_V_m=maximum,winner_direction_index=winner)
   for p,h in before.items():guard();require(sha(p)==h,'Original numerical evidence changed')
   new(OUT/'artifact-sha256.json',{p.name:dict(SHA256=sha(p),bytes=p.stat().st_size)for p in OUT.iterdir()if p.is_file()});receipt.update(status='cached_2074_direction_modulation_completed',ROI_mean_V_m=target['mean'],ROI_P10_V_m=target['p10'],new_native_field_solves=0)
  except BaseException as e:receipt.update(error_type=type(e).__name__,error=str(e));raise
  finally:
   signal.setitimer(signal.ITIMER_REAL,0);stop.set();thread.join(timeout=2);elapsed=time.monotonic()-start;ledger=policy.load_ledger(LEDGER);ledger['spent_seconds']+=elapsed;ledger['runs'].append(dict(run_id=RUN.name,stage='cached_modulation_completion',status=receipt['status'],seconds=elapsed,finished_utc=bounded.now()));tmp=LEDGER.with_name('task1-budget-completion.tmp')
   with tmp.open('x')as f:json.dump(ledger,f,ensure_ascii=False,separators=(',',':'),allow_nan=False)
   os.replace(tmp,LEDGER);receipt.update(elapsed_seconds=elapsed,finished_utc=bounded.now(),remaining_approved_seconds=policy.remaining_seconds(ledger),resources=state);new(OUT/'receipt.json',receipt)
   for s,v in previous.items():signal.signal(s,v)
   print(json.dumps(receipt,ensure_ascii=False))
if __name__=='__main__':main()
